//
//  CloudIDOne.h
//  CloudIDOne
//
//  Copyright © 2017 Synacor. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for CloudIDOne.
FOUNDATION_EXPORT double CloudIDOneVersionNumber;

//! Project version string for CloudIDOne.
FOUNDATION_EXPORT const unsigned char CloudIDOneVersionString[];
